import java.util.Objects;

public class Teacher implements Comparable<Teacher> {
  private String imie;
  private String nazwisko;
  private TeacherCondition stan;
  private int rok_urodzenia;
  private double wynagrodzenie;


  //konstruktor
  public Teacher(String imie, String nazwisko, TeacherCondition stan, int rok_urodzenia, double wynagrodzenie ) {
      this.imie = imie;
      this.nazwisko = nazwisko;
      this.stan = stan;
      this.rok_urodzenia = rok_urodzenia;
      this.wynagrodzenie = wynagrodzenie;

  }

  public void printing(){
      System.out.println("Imię i nazwisko: " + imie + " " + nazwisko);
      System.out.println("Stan: " + stan);
      System.out.println("Rok urodzenia: " + rok_urodzenia);
      System.out.println("Wynagrodzenie: " + wynagrodzenie);
  }

  //gettery i settery

    public String getImie() {
      return imie;
    }

    public String getNazwisko() {
      return nazwisko;
    }

    public TeacherCondition getStan() {
      return stan;
    }

    public void setStan(TeacherCondition stan) {
      this.stan = stan;
    }

    public int getRok_urodzenia() {
      return rok_urodzenia;
    }

    public double getWynagrodzenie() {
      return wynagrodzenie;
    }

    public void setWynagrodzenie(double wynagrodzenie) {
      this.wynagrodzenie = wynagrodzenie;
    }



  @Override
  public int compareTo(Teacher other) {
      return this.nazwisko.compareTo(other.nazwisko);
  }

  @Override
    public boolean equals(Object o) {
      if (this == o) return true;
      if (o == null || getClass() != o.getClass()) return false;
      Teacher teacher = (Teacher) o;
      return Objects.equals(imie, teacher.imie) && Objects.equals(nazwisko, teacher.nazwisko);

  }

  @Override
    public int hashCode() {
      return Objects.hash(imie, nazwisko);
  }

}
