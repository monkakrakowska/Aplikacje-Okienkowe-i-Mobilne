import  java.util.*;

public class main {
    public static void main(String[] args) {
        Teacher nauczyciel1 = new Teacher("Monika", "Krakowska", TeacherCondition.OBECNY, 2003, 5000 );
        Teacher nauczyciel2 = new Teacher("Anna", "Hellmann", TeacherCondition.DELEGACJA, 2004, 3000 );
        Teacher nauczyciel3 = new Teacher("Karolina", "Jędryczka", TeacherCondition.NIEOBECNY, 2003, 4500 );
        Teacher nauczyciel4 = new Teacher("Julia", "Piśniakowska", TeacherCondition.OBECNY, 2002, 3500 );

        ClassTeacher class1 = new ClassTeacher("Grupa matematyczna", 2);
        class1.addTeacher(nauczyciel1);
        class1.addTeacher(nauczyciel2);
        class1.addTeacher(nauczyciel3); //próba dodania kolejnego nauczyciela po przekroczeniu maksymalnej pojemności grupy

        class1.addSalary(nauczyciel1, 150.0);

        class1.removeTeacher(nauczyciel2);
        class1.addTeacher(nauczyciel3);

        class1.changeCondition(nauczyciel3, TeacherCondition.CHORY);

        Teacher znaleziony = class1.search("Jędryczka");
        if (znaleziony != null) {
            System.out.println("Znaleziono nauczyiela!");
            znaleziony.printing();
        }else{
            System.out.println("Nie znaleziono nauczyiela!");
        }

        List<Teacher> znaleziony2 = class1.searchPartial("Jęd");
        System.out.println("Nauczyciele z fragmentem 'Jęd' w nazwisku: ");
        for (Teacher teacher : znaleziony2) {
            teacher.printing();
        }

        long liczbaChorych = class1.countByCondition(TeacherCondition.CHORY);
        System.out.println("Liczba chorych: " + liczbaChorych);

        System.out.println("Podsumowanie wszystkich nauczycieli w grupie: ");
        class1.summary();

        System.out.println("Nauczyciele posortowani alfabetycznie po nazwisku");
        List<Teacher> posortowane = class1.sortByName();
        for (Teacher teacher : posortowane) {
            teacher.printing();
        }

        System.out.println("Nauczyciele posortowani po wynagrodzeniu: ");
        List<Teacher> posortowanie2 = class1.sortBySalary();
        for (Teacher teacher : posortowanie2) {
            teacher.printing();
        }

        Teacher max = class1.max();
        System.out.println("Nauczyciel o najwyższym wynagrodzeniu:");
        max.printing();
    }
}
