import java.util.*;

public class ClassTeacher {
    public String nazwa_grupy;
    public List<Teacher> lista_nauczycieli;
    public int max_ilosc_nauczycieli;

    public ClassTeacher(String nazwa_grupy, int max_ilosc_nauczycieli) {
        this.nazwa_grupy = nazwa_grupy;
        this.max_ilosc_nauczycieli = max_ilosc_nauczycieli;
        this.lista_nauczycieli = new ArrayList<>();
    }

    public void addTeacher(Teacher teacher) {
        if (lista_nauczycieli.size() < max_ilosc_nauczycieli) {
            if(!lista_nauczycieli.contains(teacher)) {
                lista_nauczycieli.add(teacher);
                System.out.println("Dodano nauczyciela.");
            } else {
                System.out.println("Nauczyciel o podanych danych juz istnieje.");
            }
        }else{
            System.out.println("Przekroczono maksymalną pojemność grupy!");
        }
    }

    public void addSalary(Teacher teacher, double kwota) {
        if (lista_nauczycieli.contains(teacher)) {
            teacher.setWynagrodzenie(teacher.getWynagrodzenie() + kwota);
            System.out.println("Zaktualizowano wynagrodzenie nauczyciela. ");
        }
    }

    public void removeTeacher(Teacher teacher) {
        if (lista_nauczycieli.contains(teacher)) {
            lista_nauczycieli.remove(teacher);
            System.out.println("Usunięto nauczyciela.");
        }else{
            System.out.println("Nie znaleziono nauczyciela o podanych danych.");
        }
    }

    public void changeCondition(Teacher teacher, TeacherCondition stan) {
        if (lista_nauczycieli.contains(teacher)) {
            teacher.setStan(stan);
            System.out.println("Zaktualizowano stan nauczyciela.");
        }
    }

    public Teacher search (String nazwisko) {
        for (Teacher t : lista_nauczycieli) {
            if (t.getNazwisko().equalsIgnoreCase(nazwisko)) {
                return t;
            }
        }
        System.out.println("Nie znaleziono nauczyciela o podanych danych.");
        return null;
    }

    public List<Teacher> searchPartial(String fragment){
        List<Teacher> result = new ArrayList<>();
        for (Teacher t : lista_nauczycieli) {
            if (t.getNazwisko().contains(fragment) || t.getImie().contains(fragment)){
                result.add(t);
            }
        }
        return result;
    }

    public long countByCondition(TeacherCondition stan){
        return lista_nauczycieli.stream().filter(t -> t.getStan() == stan).count();

    }

    public void summary(){
        for (Teacher t : lista_nauczycieli) {
            t.printing();
        }
    }

    public List<Teacher> sortByName(){
        Collections.sort(lista_nauczycieli);
        return lista_nauczycieli;
    }

    public List<Teacher> sortBySalary(){
        lista_nauczycieli.sort(Comparator.comparingDouble(Teacher::getWynagrodzenie).reversed());
        return lista_nauczycieli;
    }

    //najwyzsze wynagrodzenie
    public Teacher max(){
        return Collections.max(lista_nauczycieli, Comparator.comparingDouble(Teacher::getWynagrodzenie));
    }



}
