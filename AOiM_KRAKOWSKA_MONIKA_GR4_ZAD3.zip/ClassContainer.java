import java.util.*;

public class ClassContainer {
    private Map<String, ClassTeacher> grupyNauczycielskie;

    public ClassContainer() {
        grupyNauczycielskie = new HashMap<>();
    }

    public void addClass(String nazwaGrupy, int maxNauczycieli) {
        if(!grupyNauczycielskie.containsKey(nazwaGrupy)) {
            grupyNauczycielskie.put(nazwaGrupy, new ClassTeacher(nazwaGrupy, maxNauczycieli));
            System.out.println("Dodano grupę o nazwie: " + nazwaGrupy);
        }else{
            System.out.println("Grupa o takiej nazwie już istnieje!");
        }

    }

    public void removeClass(String nazwaGrupy) {
        if (grupyNauczycielskie.remove(nazwaGrupy) != null) {
            System.out.println("Usunięto grupę o nazwie" + nazwaGrupy);
        }else{
            System.out.println("Grupa o takiej nazwie nie istnieje!");
        }
    }

    public List<String> findEmpty(){
        List<String> pusteGrupy = new ArrayList<>();
        for (Map.Entry<String, ClassTeacher> entry : grupyNauczycielskie.entrySet()) {
            if (entry.getValue().countByCondition(TeacherCondition.OBECNY) == 0){
                pusteGrupy.add(entry.getKey());
            }
        }
        return pusteGrupy;
    }


    public void summary(){
        for (Map.Entry<String, ClassTeacher> entry : grupyNauczycielskie.entrySet()) {
            String nazwaGrupy = entry.getKey();
            int totalTeachers = entry.getValue().lista_nauczycieli.size();
            double capacity = (double) totalTeachers / entry.getValue().max_ilosc_nauczycieli * 100;
            System.out.println("Grupa o nazwie: " + nazwaGrupy + " - " + capacity + "% zapełnienia");
        }
    }
}
