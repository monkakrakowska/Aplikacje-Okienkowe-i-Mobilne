import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Teacher {
  private final StringProperty name;
  private final StringProperty subject;

  public Teacher(String name, String subject) {
    this.name = new SimpleStringProperty(name);
    this.subject = new SimpleStringProperty(subject);
  }

  public String getName() {
    return name.get();
  }

  public void setName(String name) {
    this.name.set(name);
  }

  public StringProperty nameProperty() {
    return name;
  }

  public String getSubject() {
    return subject.get();
  }

  public void setSubject(String subject) {
    this.subject.set(subject);
  }

  public StringProperty subjectProperty() {
    return subject;
  }
}
