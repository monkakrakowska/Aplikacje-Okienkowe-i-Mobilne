import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class MainApp extends Application {
    private TableView<Teacher> teacherTable = new TableView<>();
    private ObservableList<Teacher> teacherList = FXCollections.observableArrayList();

    @Override
    public void start(Stage primaryStage) {
        // Layout główny
        BorderPane root = new BorderPane();

        // Konfiguracja kolumn tabeli
        TableColumn<Teacher, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<Teacher, String> subjectColumn = new TableColumn<>("Subject");
        subjectColumn.setCellValueFactory(new PropertyValueFactory<>("subject"));

        // Dodanie kolumn do tabeli
        teacherTable.getColumns().addAll(nameColumn, subjectColumn);
        teacherTable.setItems(teacherList);

        // Przykładowi nauczyciele
        teacherList.add(new Teacher("John Smith", "Mathematics"));
        teacherList.add(new Teacher("Jane Doe", "Physics"));

        // Przyciski i pole edycyjne
        TextField filterField = new TextField();
        filterField.setPromptText("Search by last name");
        filterField.setOnAction(e -> filterTeachers(filterField.getText()));

        Button addButton = new Button("Add Teacher");
        addButton.setOnAction(e -> addTeacher());

        Button deleteButton = new Button("Delete Teacher");
        deleteButton.setOnAction(e -> deleteTeacher());

        Button modifyButton = new Button("Modify Data");
        modifyButton.setOnAction(e -> modifyTeacher());

        Button sortButton = new Button("Sort");
        sortButton.setOnAction(e -> sortTeachers());

        HBox buttons = new HBox(10, addButton, deleteButton, modifyButton, sortButton);
        VBox controls = new VBox(10, filterField, buttons);

        root.setCenter(teacherTable);
        root.setBottom(controls);

        Scene scene = new Scene(root, 800, 600);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Teacher Management System");
        primaryStage.show();
    }

    private void addTeacher() {
        // Logika dodawania nowego nauczyciela
        teacherList.add(new Teacher("New Teacher", "New Subject"));
    }

    private void deleteTeacher() {
        // Logika usuwania zaznaczonego nauczyciela
        Teacher selectedTeacher = teacherTable.getSelectionModel().getSelectedItem();
        if (selectedTeacher != null) {
            teacherList.remove(selectedTeacher);
        } else {
            showAlert("No teacher selected", "Please select a teacher to delete.");
        }
    }

    private void modifyTeacher() {
        // Logika modyfikacji danych nauczyciela
        Teacher selectedTeacher = teacherTable.getSelectionModel().getSelectedItem();
        if (selectedTeacher != null) {
            selectedTeacher.setName("Modified Name");
            teacherTable.refresh();
        } else {
            showAlert("No teacher selected", "Please select a teacher to modify.");
        }
    }

    private void sortTeachers() {
        // Logika sortowania nauczycieli
        teacherList.sort((t1, t2) -> t1.getName().compareToIgnoreCase(t2.getName()));
    }

    private void filterTeachers(String lastName) {
        // Logika filtrowania nauczycieli po nazwisku
        ObservableList<Teacher> filteredList = FXCollections.observableArrayList();
        for (Teacher teacher : teacherList) {
            if (teacher.getName().toLowerCase().contains(lastName.toLowerCase())) {
                filteredList.add(teacher);
            }
        }
        teacherTable.setItems(filteredList);
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
