public enum TeacherCondition {
    OBECNY("Obecny"),
    DELEGACJA("Delegacja"),
    CHORY("Chory"),
    NIEOBECNY("Nieobecny");

    private String description;

    TeacherCondition(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return description;
    }

}
