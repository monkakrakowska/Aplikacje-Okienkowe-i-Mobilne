public class Triangle extends Figure implements Printing {
    private double a;
    private double b;
    private double c;

    public Triangle(double a, double b, double c) {
        if (a + b <= c || a + c <= b || b + c <= a) {
            throw new IllegalArgumentException("Podane dlugosci bokow nie utworza trojkata.");

        }
        this.a = a;
        this.b = b;
        this.c = c;
    }


    @Override
    double calculateArea() {
        double s = (a + b + c) / 2;
        return Math.sqrt(s * (s - a) * (s - b) * (s - c));
    }
    @Override
    double calculatePerimeter() {
        return a + b + c;
    }
    @Override
    public void print(){
        System.out.println("Wymiary trojkata: a = " + a + ", b = " + b + ", c = " + c);
        System.out.println("Obwod: " + calculatePerimeter());
        System.out.println("Pole: " + calculateArea());
    }
}