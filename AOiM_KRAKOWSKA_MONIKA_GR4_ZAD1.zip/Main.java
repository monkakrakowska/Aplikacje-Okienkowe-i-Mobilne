public class Main {
    public static void main(String[] args) {
        GeometryCalculatorUI ui = new GeometryCalculatorUI();
        ui.start(); // Rozpoczęcie programu
    }
}
