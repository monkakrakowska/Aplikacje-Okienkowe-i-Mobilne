import java.util.Scanner;

public class GeometryCalculatorUI {
    private final Scanner scanner;
    private final GeometryCalculatorLogic logic;

    public GeometryCalculatorUI() {
        this.scanner = new Scanner(System.in);
        this.logic = new GeometryCalculatorLogic();
    }

    public void start() {
        boolean running = true;

        while (running) {

            System.out.println("Wybierz figure:");
            System.out.println("1. Trojkat");
            System.out.println("2. Kwadrat");
            System.out.println("3. Kolo");
            System.out.println("4. Graniastoslup");
            System.out.println("5. Wyswietl dane figury");
            System.out.println("6. Wyjscie");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1 -> createTriangle();
                case 2 -> createSquare();
                case 3 -> createCircle();
                case 4 -> createPrism();
                case 5 -> displayFigureInfo();
                case 6 -> {
                    running = false;
                    System.out.println("Zakonczenie pracy programu.");
                }
                default -> System.out.println("Blad.");
            }

            System.out.println();
        }

        scanner.close();
    }

    private void createTriangle() {
        System.out.println("Podaj dlugosci bokow (a, b, c): ");
        double a = scanner.nextDouble();
        double b = scanner.nextDouble();
        double c = scanner.nextDouble();
        logic.createTriangle(a, b, c);
    }

    private void createSquare() {
        System.out.println("Podaj dlugosc boku:");
        double a = scanner.nextDouble();
        logic.createSquare(a);
    }

    private void createCircle() {
        System.out.println("Podaj promien: ");
        double r = scanner.nextDouble();
        logic.createCircle(r);
    }

    private void createPrism() {
        if (logic.getBaseFigure() != null) {
            System.out.println("Podaj wysokosc graniastoslupa:");
            double height = scanner.nextDouble();
            logic.createPrism(height);
        } else {
            System.out.println("Wybierz najpierw podstawe graniastoslupa! ");
        }
    }

    private void displayFigureInfo() {
        if (logic.getBaseFigure() != null) {
            logic.displayFigureInfo();
        } else {
            System.out.println("Wybierz figure.");
        }
    }
}
