public class Square extends Figure implements Printing{
    private double a;

    public Square(double a) {
        this.a = a;
    }

    @Override
    double calculateArea() {
        return a*a;
    }

    @Override
    double calculatePerimeter() {
        return 4*a;
    }

    @Override
    public void print() {
        System.out.println("Kwadrat- wymiary: bok= " + a);
        System.out.println("Obwod: " + calculatePerimeter());
        System.out.println("Pole: " + calculateArea());
    }
}
