public class GeometryCalculatorLogic {
    private Figure baseFigure;

    public Figure getBaseFigure() {
        return baseFigure;
    }

    public void createTriangle(double a, double b, double c) {
        try {
            baseFigure = new Triangle(a, b, c);
            if (baseFigure instanceof Printing) {
                ((Printing) baseFigure).print();
            }
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }

    public void createSquare(double a) {
        baseFigure = new Square(a);
        if (baseFigure instanceof Printing) {
            ((Printing) baseFigure).print();
        }
    }

    public void createCircle(double r) {
        baseFigure = new Circle(r);
        if (baseFigure instanceof Printing) {
            ((Printing) baseFigure).print();
        }
    }

    public void createPrism(double height) {
        if (baseFigure != null) {
            ThreeDim prism = new ThreeDim(baseFigure, height);
            prism.print();
        } else {
            System.out.println("Najpierw musisz wybrac figure bazową.");
        }
    }

    public void displayFigureInfo() {
        if (baseFigure != null && baseFigure instanceof Printing) {
            ((Printing) baseFigure).print();
        } else {
            System.out.println("Nie wybrano figury.");
        }
    }
}
