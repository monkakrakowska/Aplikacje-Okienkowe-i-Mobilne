public class ThreeDim extends Figure implements Printing {
    private Figure baseFigure;
    private double height;

    public ThreeDim(Figure baseFigure, double height) {
        this.baseFigure = baseFigure;
        this.height = height;
    }

    @Override
    double calculateArea() {
        return 2 * baseFigure.calculateArea() + baseFigure.calculatePerimeter() * height;
    }

    @Override
    double calculatePerimeter() {
        return baseFigure.calculatePerimeter();
    }

    public double calculateVolume() {
        return baseFigure.calculateArea() * height;

    }

        @Override
    public void print(){
            if (baseFigure instanceof Printing) {
                System.out.println("Graniastosłup o podstawie:");
                ((Printing) baseFigure).print();
            } else {
                System.out.println("Nie można wydrukować podstawy graniastosłupa.");
            }
        System.out.println("Wysokosc: " + height);
        System.out.println("Pole powierzchni: " + calculateArea());
        System.out.println("Objetosc: " + calculateVolume());
        }
}

